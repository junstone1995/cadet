# Dossier de Test pour le cursus 42

gnl:
-test gnl sans bonus

printf :
-test printf sans bonus
