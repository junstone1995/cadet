#ifndef CONV_U_BIGU_TEST_H
# define CONV_U_BIGU_TEST_H

# include "test.h"

int		u_basic_01(void);
int		u_basic_02(void);
int		u_basic_03(void);
int		u_basic_04(void);
int		u_modifiers_01(void);
int		u_modifiers_02(void);
int		u_modifiers_03(void);
int		u_modifiers_04(void);
int		u_modifiers_05(void);
int		u_modifiers_06(void);
int		u_precision_01(void);
int		u_precision_02(void);
int		u_precision_03(void);
int		u_precision_04(void);
int		u_precision_05(void);
int		u_precision_06(void);
int		u_padding_01(void);
int		u_padding_02(void);
int		u_padding_03(void);
int		u_padding_04(void);
int		u_padding_05(void);
int		u_padding_06(void);
int		u_all_01(void);
int		u_all_02(void);
int		u_all_03(void);
int		u_all_04(void);

#endif
