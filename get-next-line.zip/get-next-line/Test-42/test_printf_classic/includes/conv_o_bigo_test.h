#ifndef CONV_O_BIGO_TEST_H
# define CONV_O_BIGO_TEST_H

# include "test.h"

int		o_basic_01(void);
int		o_basic_02(void);
int		o_basic_03(void);
int		o_basic_04(void);
int		o_basic_05(void);
int		o_basic_06(void);
int		o_flags_01(void);
int		o_flags_02(void);
int		o_flags_03(void);
int		o_modifiers_01(void);
int		o_modifiers_02(void);
int		o_modifiers_03(void);
int		o_modifiers_04(void);
int		o_modifiers_05(void);
int		o_modifiers_06(void);
int		o_precision_01(void);
int		o_precision_02(void);
int		o_precision_03(void);
int		o_precision_04(void);
int		o_precision_05(void);
int		o_precision_06(void);
int		o_precision_07(void);
int		o_padding_01(void);
int		o_padding_02(void);
int		o_padding_03(void);
int		o_padding_04(void);
int		o_padding_05(void);
int		o_padding_06(void);
int		o_padding_07(void);
int		o_padding_08(void);
int		o_all_01(void);
int		o_all_02(void);
int		o_all_03(void);
int		o_all_04(void);
int		o_all_05(void);
int		o_all_06(void);

#endif
