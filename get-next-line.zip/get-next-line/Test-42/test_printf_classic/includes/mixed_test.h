#ifndef MIXED_TEST_H
# define MIXED_TEST_H

# include "test.h"

int		mix_test_01(void);
int		mix_test_02(void);
int		mix_test_03(void);
int		mix_test_04(void);
int		mix_test_05(void);

#endif
