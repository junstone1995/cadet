#ifndef CONV_D_I_BIGD_TEST_H
# define CONV_D_I_BIGD_TEST_H

# include "test.h"

int		d_basic_01(void);
int		d_basic_02(void);
int		d_basic_03(void);
int		d_basic_04(void);
int		d_basic_05(void);
int		d_basic_06(void);
int		d_basic_07(void);
int		d_basic_08(void);
int		d_precision_01(void);
int		d_precision_02(void);
int		d_precision_03(void);
int		d_precision_04(void);
int		d_precision_05(void);
int		d_precision_06(void);
int		d_precision_07(void);
int		d_padding_01(void);
int		d_padding_02(void);
int		d_padding_03(void);
int		d_padding_04(void);
int		d_padding_05(void);
int		d_padding_06(void);
int		d_padding_07(void);
int		d_all_01(void);
int		d_all_02(void);
int		d_all_03(void);
int		d_all_04(void);
int		d_all_05(void);
int		d_all_06(void);

#endif
