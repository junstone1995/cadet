#ifndef CONV_BIGC_TEST_H
# define CONV_BIGC_TEST_H

# include "test.h"

int		bigc_basic_01(void);
int		bigc_basic_02(void);
int		bigc_basic_03(void);
int		bigc_basic_04(void);
int		bigc_basic_05(void);
int		bigc_basic_06(void);
int		bigc_basic_07(void);
int		bigc_basic_08(void);
int		bigc_basic_09(void);
int		bigc_basic_10(void);
int		bigc_basic_11(void);
int		bigc_basic_12(void);
int		bigc_basic_13(void);
int		bigc_basic_14(void);
int		bigc_basic_15(void);
int		bigc_padding_01(void);
int		bigc_padding_02(void);
int		bigc_padding_03(void);
int		bigc_all_01(void);
int		bigc_all_02(void);
int		bigc_all_03(void);
int		bigc_all_04(void);

#endif
