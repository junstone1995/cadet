#ifndef BASICS_TEST_H
# define BASICS_TEST_H

# include "test.h"

int		basics_test_01(void);
int		basics_test_02(void);

#endif
