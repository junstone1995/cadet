#ifndef CONV_X_BIGX_TEST_H
# define CONV_X_BIGX_TEST_H

# include "test.h"

int		x_basic_01(void);
int		x_basic_02(void);
int		x_basic_03(void);
int		x_basic_04(void);
int		x_basic_05(void);
int		x_flags_01(void);
int		x_flags_02(void);
int		x_flags_03(void);
int		x_modifiers_01(void);
int		x_modifiers_02(void);
int		x_modifiers_03(void);
int		x_modifiers_04(void);
int		x_modifiers_05(void);
int		x_modifiers_06(void);
int		x_modifiers_07(void);
int		x_precision_01(void);
int		x_precision_02(void);
int		x_precision_03(void);
int		x_precision_04(void);
int		x_precision_05(void);
int		x_precision_06(void);
int		x_precision_07(void);
int		x_precision_08(void);
int		x_padding_01(void);
int		x_padding_02(void);
int		x_padding_03(void);
int		x_padding_04(void);
int		x_padding_05(void);
int		x_padding_06(void);
int		x_padding_07(void);
int		x_all_01(void);
int		x_all_02(void);
int		x_all_03(void);
int		x_all_04(void);
int		x_all_05(void);
int		x_all_06(void);
int		x_all_07(void);
int		x_all_08(void);
int		x_all_09(void);

#endif
