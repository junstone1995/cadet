#!/bin/bash
while true;
do
	leaks a.out;
	sleep 2;
done

